package GGTeam.F3API;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class F3Apirest2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
